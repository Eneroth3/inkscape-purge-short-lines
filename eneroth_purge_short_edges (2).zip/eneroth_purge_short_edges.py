#!/usr/bin/env python

# Test code: Make all nodes have red stroke (assume all are paths).

import inkex
from simplestyle import *

class EnerothPurgeShortEdges(inkex.Effect):
  def __init__(self):
    inkex.Effect.__init__(self)
    self.OptionParser.add_option('-w', '--length', action = 'store',
      type = 'float', dest = 'length', default = 10.0)

  def effect(self):
    length = self.options.length
    svg = self.document.getroot()

    if len(self.selected)==0:
      self.iterate_node(self.document.getroot())
    else:
      for id, node in self.selected.iteritems():
        self.iterate_node(node)

  def iterate_node(self, node):
    self.do_node(node)
    for child in node:
      self.iterate_node(child)

  def do_node(self, node):
    if node.attrib.has_key('style'):
      style = node.get('style') # Presentation attributes not supported.
      if style:
        declarations = style.split(';') # ";" within comments or strings not supported.
        for i,decl in enumerate(declarations):
          (prop, val) = decl.split(':', 2)
          prop = prop.strip().lower()
          if prop == 'stroke':
            new_val = "red"
            declarations[i] = prop + ':' + new_val
      node.set('style', ';'.join(declarations))

EnerothPurgeShortEdges().affect()

#!/usr/bin/env python

import inkex
from simplestyle import *

class EnerothPurgeShortEdges(inkex.Effect):
    def __init__(self):
        inkex.Effect.__init__(self)
        self.OptionParser.add_option('-w', '--length', action = 'store',
          type = 'float', dest = 'length', default = 10.0)

    def effect(self):
        length = self.options.length
        svg = self.document.getroot()

        width  = self.unittouu(svg.get('width'))
        height = self.unittouu(svg.get('height'))
        layer = inkex.etree.SubElement(svg, 'g')
        layer.set(inkex.addNS('label', 'inkscape'), 'Hello %s Layer' % (length))
        layer.set(inkex.addNS('groupmode', 'inkscape'), 'layer')
        text = inkex.etree.Element(inkex.addNS('text','svg'))
        text.text = 'Hello %s!' % (length)
        text.set('x', str(width / 2))
        text.set('y', str(height / 2))
        style = {'text-align' : 'center', 'text-anchor' : 'middle'}
        text.set('style', formatStyle(style))
        layer.append(text)

EnerothPurgeShortEdges().affect()
